# Daily Vaccinations

#Necessry libraries
library(readr)
library(dplyr)
library(ggplot2)
library(gridExtra)
library(zoo)
library(lubridate)

# Importing the data
case_data <- read.csv(file = "/Users/jeremiahmodzuka/Downloads/cumulative-case-data.csv")

case_data$date <- dmy(case_data$date)

# Filter case data for the specified date range for volatility calculation
vaccination_data <- case_data %>%
  filter(date >= as.Date("2021-04-01") & date <= as.Date("2022-04-01")) %>%
  select(date, vaccinated_daily)

# Calculate rolling volatility of daily vaccinations (using a 30-day window for example)
vaccination_data$volatility <- rollapply(vaccination_data$vaccinated_daily, 30, sd, fill = NA, align = 'right', na.rm = TRUE)

# Remove NA values from volatility for plotting
vaccination_data <- vaccination_data %>%
  filter(!is.na(volatility))

# Filter for the last few days to show in the table
table_data <- case_data %>%
  filter(date >= as.Date("2022-03-31") & date <= as.Date("2022-04-07")) %>%
  select(date, vaccinated_daily) %>%
  arrange(desc(date))

# Change date format in table_data
table_data$date <- format(table_data$date, "%d %b")

# Create the table graphic
table_grob <- tableGrob(table_data)

# Specify explicit dates for x-axis
date_breaks <- as.Date(c("2021-04-01", "2021-07-01", "2021-10-01", "2022-01-01", "2022-04-01"))

# Plot the volatility
ggplot(vaccination_data, aes(x = date, y = volatility)) +
  geom_col(color = "green", size = 0.1) + # Adjust size for thinner line
  scale_x_date(breaks = date_breaks, date_labels = "%d %b") +
  scale_y_continuous(limits = c(0, 300000), breaks = seq(0, 300000, 100000)) +
  labs(title = "Daily Vaccinations Volatility",
       x = "Date",
       y = "Volatility") +
  theme_minimal() +
  annotate("text", x = as.Date("2022-01-01"), y = 150000, label = "Recent Daily Vaccinations", hjust = 0, vjust = 0, size = 5, angle = 0) +
  annotation_custom(grob = table_grob, xmin = as.Date("2022-01-01"), xmax = as.Date("2022-04-01"), ymin = 100000, ymax = 300000)